1. sdkmgr
sdkmgr工具可以查看、安装/更新和卸载多个HarmonyOS SDK包，支持通过自动化构建脚本调用。

2. codelinter
codelinter针对ArkTS/TS代码进行最佳实践、编程规范方面的检查，当前还包括ArkTS语法规则检查。
开发者可根据扫描结果中告警提示手工修复代码缺陷，或者执行一键式自动修复，在开发阶段保障代码质量。

3. ohpm
ohpm是鸿蒙生态三方库的包管理工具。